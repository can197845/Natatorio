<?php
ini_set('display_errors',1);
include './include/conexion.php';

if  ( ( isset($_POST['Alta'])) ) {

     extract($_POST);

     $pass=md5($_POST['pass']);
   
    $sql="INSERT INTO user (id_user, Nombre, apellido, correo, clave) VALUES 
    (NULL, '$nombreNadador', '$apellidoNadador', '$correoNadador', '$pass')";
    
    $result=mysqli_query($conexion, $sql);
 



}
include './include/head.php';
?>


<body>
    
    <main>
        
       
        <!-- Sección Ser un Nadador -->
        <section id="nadador" class="container" >
            <div class="row justify-content-center">
                <div class="col-lg-7 col-xl-8">
                    <p class="text-center">Convertite en un nadador</p>
                    <h2 class="text-center">DATOS</h2>
                    <p class="text-center"></p>
                    
                    <form action="alta.php" method="post" enctype="multipart/form-data" name="contact-form" >
                        <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="nombreNadador" id="nombreNadador" type="text" class="form-control" placeholder="Nombre" aria-label="Nombre" required>
                                <label for="nombreNadador">Nombre</label>
                            </div>
                            <div class="form-floating col-md mb-3">
                                <input name="apellidoNadador" id="apellidoNadador" type="text" class="form-control" placeholder="Apellido" aria-label="Apellido" required>
                                <label for="apellidoNadador">Apellido</label>
                            </div>
                        </div>
                        <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="correoNadador" id="correoNadador" type="email" class="form-control" placeholder="Email" aria-label="Email" required>
                                <label for="correoNadador">Correo</label>
                            </div>
                        </div>
                        <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="pass" id="pass" type="password" class="form-control" placeholder="Contraseña"  required>
                                <label for="pass">Contraseña</label>
                            </div>
                        </div>
                        
                        <div class="row">
                                <div class="d-grid">
                                    <button type="submit" name="Alta" class="btn btn-success btn-lg btn-form">Enviar</button>
                                </div>
                        </div>
                    </form>
                    <DIV style="margin-top: 50px;">
                    <a href="index.php" 
                      style=
                      "text-decoration:none;
                        color:white; 
                        font-size:1rem; 
                        padding: 10px;
                        border: 2px solid black; 
                        border-radius: 5px;
                        background:gray;">Volver</a>
                        </DIV>  
                </div>
            </div>
        </section>
    </main>
    <footer>
       
    </footer>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
        crossorigin="anonymous"></script>
    
</body>

</html>
