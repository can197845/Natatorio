<?php

//ini_set('display_errors',1);
include './include/conexion.php';
include './include/head.php';
include './include/seccionAct.php';
if  ( ( isset($_POST['Modificar'])) ) {

     extract($_POST);

       
   
    $sql="Update user set  Nombre='$Nombre', 
                           apellido='$apellido', 
                           correo='$correo'
                           where id_user='$id_user'";
    
        
    $result=mysqli_query($conexion, $sql);


}
?>


<body>
    
    <main>
       
        <section id="serNadador" class="container" >
            <div class="row justify-content-center">
                <div class="col-lg-7 col-xl-8">
                    <p class="text-center">Conviértete en un</p>
                    <h2 class="text-center">NADADOR</h2>
                    <p class="text-center"></p>
                    <?php 
                     $id_user=$_REQUEST["id_user"];
                     //echo $id;
                     $sql="select * from user where id_user='$id_user'";
                     $result=mysqli_query($conexion, $sql);
                     $row = mysqli_fetch_array($result);
                    ?>

                    <form action="modificar.php" method="post" enctype="multipart/form-data" name="contact-form" >
                        <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="Nombre" id="Nombre" type="text" class="form-control" value="<?php echo $row["Nombre"] ?>" aria-label="NombreNadador" required>
                               
                                <input name="id_user" type="hidden"  value="<?php echo $row["id_user"] ?>" >
                                <label for="Nombre">Nombre</label>
                            </div>
                            <div class="form-floating col-md mb-3">
                                <input name="apellido" id="apellido" type="text" class="form-control" value="<?php echo $row["apellido"] ?>" aria-label="Apellido" required>
                                <label for="apellido">Apellido</label>
                            </div>
                        </div>
                        <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="correo" id="correo" type="email" class="form-control" value="<?php echo $row["correo"] ?>"required>
                                <label for="correo">Correo</label>
                            </div>
                        </div>
                       
                        <div class="row">
                            <div class="col mb-3">
                                </div>
                                 <div class="d-grid">
                                    <button type="submit" name="Modificar" class="btn btn-success btn-lg btn-form">Modificar</button>
                                </div>
                            </div>
                        </div>
                    </form>
                      <a href="index.php">Volver</a>
                </div>
            </div>
        </section>
    </main>
    
</body>

</html>
