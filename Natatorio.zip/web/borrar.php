<?php
 //ini_set('display_errors',1);
include './include/conexion.php';
include './include/seccionAct.php';
 $id_user=$_REQUEST["id_user"];
 $sql="delete from user where id_user='$id_user'";
 //$sql = "update oradores set activo='0' where id='$id'";
 $result=mysqli_query($conexion, $sql);
 
 echo "Usuario Borrado ID= ".$id_user;
 echo "<a href=index.php>Volver</a>"
 ?>