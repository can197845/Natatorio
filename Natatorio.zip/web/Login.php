<?php
ini_set('display_errors',1);
include './include/conexion.php';


if  (isset($_POST['Login'])) {

    extract($_POST);

    $u=$_POST['correoNadador'];
    $p=md5($_POST['pass']);

    $sql = "select * from user where correo ='".$u."' and clave='".$p."' and activo='1'";
    $result = mysqli_query($conexion, $sql);
    $rstlogin = mysqli_fetch_array($result);	

    if ($rstlogin) {

        session_name('back');
		    		session_start();
			        $_SESSION['Usuario']   = $rstlogin['correo'];	
				    $_SESSION['IDUsuario'] = $rstlogin['id'];
			        $_SESSION['Nombre'] = $rstlogin['Nombre'];	//$usu->ID;
			    				
				    $_SESSION['is_logged'] = 1;

        if ($rstlogin['admin'] == 0){
            header('Location: index.php');
                        
            }else{
                header ('location: listado.php');}
        
    }else{
        header('location: login.php?mensajee=Usuario o Password Incorrectos');
    }  
}

include './include/head.php';
?>


<body>
    
    <main>
        <section id="serNadador" class="container" >
            <div class="row justify-content-center">
                <div class="col-lg-7 col-xl-8">
                    
                    <p class="text-center"></p>
                    <h2 class="text-center">LOGIN</h2>
                    <p class="text-center"></p>
                    
                    <form action="Login.php" method="post" enctype="multipart/form-data" name="contact-form" >
                        
                        <div class="row gx-2">
                            <div class="form-floating col-md mb-3">
                                <input name="correoNadador" id="correoNadador" type="email" class="form-control" placeholder="Correo" aria-label="Correo" required>
                                <label for="correoNadador">Usuario</label>
                            </div>
                           
                            <div class="row gx-2">
                                <div class="form-floating col-md mb-3">
                                    <input name="pass" id="pass" type="password" class="form-control" placeholder="Contraseña" aria-label="Contraseña" required>
                                    <label for="pass">Contraseña</label>
                                </div>
                            </div>
                        
                            <div class="row">
                                <div class="col mb-3">
                               
                                    <div class="d-grid">
                                        <button type="submit" name="Login" class="btn btn-success btn-lg btn-form">Ingresar</button>
                                    </div>
                                </div>
                            </div>
                    </form>
                    <DIV style="margin-top: 50px;">
                    <a href="index.php" 
                      style=
                      "text-decoration:none;
                        color:white; 
                        font-size:1rem; 
                        padding: 10px;
                        border: 2px solid black; 
                        border-radius: 5px;
                        background:gray;">Volver</a>
                        </DIV>  
                </div>
            </div>
        </section>
    </main>
    <footer>
       
    </footer>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-u1OknCvxWvY5kfmNBILK2hRnQC3Pr17a+RTT6rIHI7NnikvbZlHgTPOOmMi466C8"
        crossorigin="anonymous"></script>
    
</body>

</html>
