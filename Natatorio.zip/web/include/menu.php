<div class="menu">
<div>
    <a href="login.php" style="text-decoration:none;">Ingreso</a>
</div>    
<div>
    <a href="alta.php" style="text-decoration:none;">Registrarse</a>
</div>    
</div>