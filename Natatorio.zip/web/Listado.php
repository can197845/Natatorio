<?php
//ini_set('display_errors',1);
include './include/conexion.php';

include './include/seccionAct.php';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="./css/Style.css">
    <title>Competencia</title>
</head>
<body>
<section style="display:flex; justify-content: center; flex-direction:column; align-items: center;">
    <div style="text-algin: center; padding:10px;">
        <h5>Busqueeda de Usuario</h5>
    </div>
        <div>
            <form action="listado.php" method="post" enctype="multipart/form-data">
            
                <label for="busqueda">Buscar Usuario: </label>
                <input type="text" name="busqueda" placeholder="Apellido de usuario" style="width: 350px;" required>
            
                <div>
                    <button type="submit" name="buscar" style="width: 200px;margin:10px; border-radius:5px;"> Buscar</button>       
                    <button style="width: 200px;margin:10px; border-radius:5px;">
                        <a href="./include/logaout.php" style="color:black;">Menu Principal</a>
                    </button>
                    <button style="width: 200px;margin:10px; border-radius:5px;">
                        <a href="listado.php" style="color:black;"><i class="bi bi-arrow-clockwise"></i> Recargar</a>
                    </button>
                </div>
                <div>
                    
                </div>
            </form>
        </div>
    </section>
    <section>
        <div class="container">
            <!-- Cabecera de la tabla de usuarios -->
            <table class="table caption-top table-responsive-sm">
            <caption><strong>Listado de Usuarios</strong></caption>
                <thead class="table-dark">
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Apellido</th>
                        <th>Correo</th>
                        <th>Acciones</th>

                    </tr>
                </thead>
                <tbody>
                    
                       <?php
                       if (isset($_POST['buscar'])) {
                            
                        // Buscar Apellido

                        $busqueda = $_POST['busqueda'];
                        // ponemos una condicion por si la busqueda se inicia vacia
                        if (empty($_POST['busqueda'])) {
                            echo "<script>alert('Debe ingresar un apellido para buscar')</script>";
                            echo "<script>window.location='listado.php'</script>";
                            } 
                            else 
                            {
                                $sql = "SELECT * FROM user WHERE apellido LIKE '%$busqueda%'";
                                $resultado = mysqli_query($conexion, $sql);
                                while ($fila = mysqli_fetch_array($resultado)) {
                                    ?>
                                <tr>
                                    <td><?php echo $fila['id_user']; ?></td>
                                    <td><?php echo $fila['Nombre']; ?></td>
                                    <td><?php echo $fila['apellido']; ?></td>
                                    <td><?php echo $fila['correo']; ?></td> 
                                    <td> 
                                        
                                            <a href="modificar.php?id_user=<?= $fila['id_user']?>"style="padding:2px; margin:5px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">
  <path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z"/>
  <path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5z"/>
</svg>
                                            </a>
                                            <a href="borrar.php?id_user=<?= $fila['id_user']?>"style="padding:2px; margin:5px;">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-trash3-fill" viewBox="0 0 16 16">
  <path d="M11 1.5v1h3.5a.5.5 0 0 1 0 1h-.538l-.853 10.66A2 2 0 0 1 11.115 16h-6.23a2 2 0 0 1-1.994-1.84L2.038 3.5H1.5a.5.5 0 0 1 0-1H5v-1A1.5 1.5 0 0 1 6.5 0h3A1.5 1.5 0 0 1 11 1.5m-5 0v1h4v-1a.5.5 0 0 0-.5-.5h-3a.5.5 0 0 0-.5.5M4.5 5.029l.5 8.5a.5.5 0 1 0 .998-.06l-.5-8.5a.5.5 0 1 0-.998.06m6.53-.528a.5.5 0 0 0-.528.47l-.5 8.5a.5.5 0 0 0 .998.058l.5-8.5a.5.5 0 0 0-.47-.528M8 4.5a.5.5 0 0 0-.5.5v8.5a.5.5 0 0 0 1 0V5a.5.5 0 0 0-.5-.5"/>
</svg></a>
                                            </button>

                                        
                                    </td>
                                    
                                </tr>
                        
                                <?php   
                            }
                        }
                       }else{
                          
                        // Seleccionamos a todos los usuarios para mostrarlos
                        
                            $sql = "SELECT * FROM `user`";
                            $resultado= mysqli_query($conexion, $sql);
                            while ($fila = mysqli_fetch_array($resultado)) {
                                ?>
                                
                                <tr>
                                    <td><?php echo $fila['id_user']; ?></td>
                                    <td><?php echo $fila['Nombre']; ?></td>
                                    <td><?php echo $fila['apellido']; ?></td>
                                    <td><?php echo $fila['correo']; ?></td>
                                    
                                </tr>
                                <?php
                            }
                       }
                        ?>
                </tbody> 
            </table>
        </div>
    </section>
</main>

</body>
</html>