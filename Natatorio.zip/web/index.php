<?php include './include/head.php';?>

<body>
<?php include './include/header.php';?>
<?php include './include/menu.php';?>

<div class="contaier config">
    
    <p class="parrafo"><strong>Bienvenidos a nuestra emocionante presentación sobre la carrera de natación! Hoy, nos sumergiremos en el mundo del agua para explorar cómo esta disciplina no solo es una forma de ejercicio físico, sino también una habilidad vital y una pasión que puede transformar vidas.

La natación es más que simplemente nadar; es una competencia que requiere fuerza, resistencia, estrategia y, sobre todo, amor por el agua. Desde los primeros días de aprendizaje hasta convertirse en un atleta olímpico, cada etapa de la carrera de natación ofrece desafíos únicos y oportunidades para crecer tanto física como mentalmente.

En nuestra presentación, descubriremos:

Los fundamentos de la natación: Aprenderemos sobre las diferentes técnicas y estilos de natación, desde el estilo libre hasta el pecho, espalda y mariposa, y cómo cada uno contribuye al rendimiento general.

Historia y evolución de la natación: Exploraremos cómo la natación ha evolucionado a lo largo de los años, desde sus orígenes competitivos hasta su actual lugar como deporte olímpico.

Beneficios físicos y mentales: Descubriremos cómo la natación mejora la salud cardiovascular, fortalece los músculos y promueve una mente tranquila y enfocada.
Preparación y entrenamiento: Hablaremos sobre los aspectos clave de la preparación para una carrera de natación, incluyendo la dieta adecuada, el entrenamiento específico y la importancia del descanso y la recuperación.
Carreras destacadas y logros históricos: Celebraremos algunos de los momentos más memorables en la historia de la natación, desde victorias olímpicas hasta récords mundiales.
La natación es un deporte inclusivo que se adapta a todas las edades y niveles de habilidad. Ya sea que estés buscando mejorar tu condición física, alcanzar metas personales o aspirar a competir a nivel nacional o internacional, la natación tiene algo para ofrecerte.

Así que, ¡sumérgete con nosotros! Prepárate para ser inspirado, motivado y listo para saltar al agua y comenzar tu viaje en la carrera de natación.</strong></p>
    <div class="contenedor d-flex">
        <img src="./image/nadador.jfif" alt="Portada" class="portada-img">
        <img src="./image/coca.png" alt="coca" class="portada-img" style="padding:10px;">
        <img src="./image/nike.png" alt="Nike" class="portada-img">
    </div>
</div>
</body>
</html>

